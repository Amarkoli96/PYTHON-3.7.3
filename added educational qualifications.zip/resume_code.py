import xlrd
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docx.shared import Pt

from docx import Document
document=Document('LOGO_FOOTER.docx')
style = document.styles['Normal']
font = style.font
font.name='Times New Roman'
font.size = Pt(12)
x= 6

loc=('RESUME_BLANK_FORMAT.xlsm')
wb=xlrd.open_workbook(loc)
sheet_no = len(wb.sheet_names()) 
current_sheet = 0

sheet=wb.sheet_by_index(current_sheet)
name=sheet.cell_value(0,1)
name = name.split(',')

document.add_paragraph().add_run(name[0]).bold = True
document.add_paragraph(name[1])
document.add_paragraph(" ")

table  = document.add_table(rows = 1,cols = 1)
table.style = 'Table Grid'
table.rows[0].cells[0].add_paragraph().add_run(sheet.cell_value(1, 0)).bold = True

shading_elm_1 = parse_xml(r'<w:shd {} w:fill="E6E6E6"/>'.format(nsdecls('w')))
table.rows[0].cells[0]._tc.get_or_add_tcPr().append(shading_elm_1)
document.add_paragraph(" ")

exp_summary=sheet.cell_value(1,1)
document.add_paragraph().add_run(exp_summary)

table  = document.add_table(rows = 1,cols = 1)
table.style = 'Table Grid'
table.rows[0].cells[0].add_paragraph().add_run(sheet.cell_value(3, 0)).bold = True
shading_elm_1 = parse_xml(r'<w:shd {} w:fill="E6E6E6"/>'.format(nsdecls('w')))
table.rows[0].cells[0]._tc.get_or_add_tcPr().append(shading_elm_1)
document.add_paragraph(" ")

tech_exp=sheet.cell_value(3,1)
document.add_paragraph(tech_exp)

table  = document.add_table(rows = 1,cols = 1)
table.style = 'Table Grid'
table.rows[0].cells[0].add_paragraph().add_run(sheet.cell_value(5, 0)).bold = True
shading_elm_1 = parse_xml(r'<w:shd {} w:fill="E6E6E6"/>'.format(nsdecls('w')))
table.rows[0].cells[0]._tc.get_or_add_tcPr().append(shading_elm_1)
document.add_paragraph(' ')

z=1
projects=int(sheet.cell_value(5,1))
while z<= projects:
    table1  = document.add_table(rows = 1,cols = 1)
    table1.style = 'Table Grid'
    table2  = document.add_table(rows = 4,cols = 2)
    table2.style = 'Table Grid'
    global x
    table1.cell(0,0).text = sheet.cell_value(x,1)
    for i in range(0,4):
        x= x+1
        for j in range(0,2):
             table2.cell(i,j).text = sheet.cell_value(x,j)
    z= z+1
    document.add_paragraph(" ")
    x= x+1

table  = document.add_table(rows = 1,cols = 1)
table.style = 'Table Grid'
table.rows[0].cells[0].add_paragraph().add_run(sheet.cell_value(4, 0)).bold = True
shading_elm_1 = parse_xml(r'<w:shd {} w:fill="E6E6E6"/>'.format(nsdecls('w')))
table.rows[0].cells[0]._tc.get_or_add_tcPr().append(shading_elm_1)
document.add_paragraph(" ")

training=sheet.cell_value(4,1)
document.add_paragraph(training)

current_sheet = current_sheet+1

document.save(name[0] +"_resume"+'.docx')

